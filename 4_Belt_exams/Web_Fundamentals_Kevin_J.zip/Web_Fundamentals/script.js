var mainbanner = document.querySelector("#mainbanner");
var numshoppingcart = document.querySelector("#numshoppingcart");
var num=0;

console.log(mainbanner);

function lefclick(){
    mainbanner.src = "images/stonepunk.png"
};

function rightclick(){
    mainbanner.src = "images/pixel-ninjas-2.png"
};

function linuxicon(){
    alert("The game is supported on Linux")
}


function shoppingcar(){
    num +=1;
    numshoppingcart.innerText=num;
}